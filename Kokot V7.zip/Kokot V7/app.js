
// import the express module 
const express = require("express");
// instanciate module to create the app
let app = express();
// port to listen 
const PORT = 3000 ;

// import path module + secondary modules 
const path = require("path");
const bodyParser = require("body-parser");
const bootstrap = require("./src/bootstrap");

// settings for the template engine 
app.set('view engine','ejs');
app.set('views', path.resolve('./src/views'))

// used when managing forms 
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended : true }));
app.use(express.static('public'));

const router = express.Router();
app.use(router);

bootstrap(app,router);

router.get("/", (req,res,next) => {
    let Message = "Bienvenue !";
    res.render("pages/index", { Message })
});

router.use((err,req,res,next) => {
    if(err) {
        return res.send(err.message)
    }
})

app.listen(PORT, err => {
    if(err) return console.log("cannot start server ... ");
    console.log("server started ! ");
});


