// params d'init de la connexion 
let url ="mongodb://kkb_user:kkb_passwd@mongo";
const bcrypt = require("bcrypt")
const saltRounds = 10

// import de l'objet MongoClient du module mongodb
const { MongoClient } = require("mongodb");

// Fonction pour gérer les input date 
function todaysDateFormated(){
    const d = new Date();
    let todayY = d.getFullYear().toString();
    let todayM = (d.getMonth()+1).toString();

    if (todayM.length < 2) {
        todayM = "0"+ todayFM;
    }
    let todayD = d.getDate().toString();
    
    if (todayD.length < 2) {
        todayD = "0" + todayFD;
    }
    let todayFormated = `${todayY}-${todayM}-${todayD}`
    return todayFormated;
}

// Fonction annexe : Permet de récupérer les transactions sur N derniers jours
function getTransactionsFromNDaysAgo(days, transactions){
    
    // --- set targetDate à aujourd'hui
    let targetDate = new Date();                                    
    
    // --- set targetDate à aujourd'hui - n*jours 
    targetDate.setDate(targetDate.getDate() - days-1);              
    
    // --- crée un array selectedTransactions dans lequel on stockera les transactions
    let selectedTransactions = [];                                  

    // --- pour chaque transactions, vérifie si elle a bien lieu après la date choisie et la stocke dans  l'array selectedTransactions
    for (let i = 0; i < transactions.length; i++) {                 

        if (transactions[i].date_transaction >= targetDate){
            selectedTransactions.push(transactions[i]);
        }
    }
    // --- retourne les selectedTransactions sous forme de tableau
    return selectedTransactions;                                    
}

//Fonction pour modifier un montant
exports.updateAmount = (req) => {
    const client = new MongoClient(url);
    async function search(req){
        let msg=""
        try{
            const database = client.db("kkb");
            const coll = database.collection("current_account");
            let accountnbr = parseInt(req.account_number_current_account)
            const query = { account_number_current_account: accountnbr };
            const account = await coll.findOne(query) //Récupération du compte
            const result = (account.balance_current_account + Number(req.amount)) //Simulation du résultat de l'opération
            let ok=true; // Variable de l'autorisation d'opération
            //Vérif si l'opération ne dépasse pas le découvert autorisé
            if (result >= account.floor_current_account){ 
                const updateDoc = {
                    $set: {
                        balance_current_account: result}
                    }
                const XXX = await coll.updateOne(query, updateDoc); // Si oui, on effectue l'opération
                msg = "Nouveau solde de votre compte "+req.account_number_current_account+" : "+result+" € "
            }
            else { 
                ok=false // Si opération impossible, on renvoie un message d'erreur
                msg = "Impossible d'effectuer votre transaction, fonds insuffisants"
            }

            // Puis on crée la ligne dans la base "transactions"
            const coll2 = database.collection("transactions"); 
            let today = todaysDateFormated();
            const insert2 = await coll2.insertOne(
                {
                    beneficiary_transaction:req.beneficiary_transaction,
                    type_transaction:req.type_transaction,
                    amount_transaction:req.amount,
                    date_transaction:today,
                    canceled_transaction:ok,
                    account_transaction:accountnbr
                })
                console.log(msg)
            return msg
        }
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return search(req)
} 

//Fonction de création du client
exports.addClient = (req) => {
    const client = new MongoClient(url);
    async function add(req){
        try{  
            //Génération aléatoire du N° de compte courant
            if(req.password_client==req.passwordConfirm) { // Vérif de la concordance des 2 passwords, sinon on renvoie une erreur
                const min = 1000000000
                const max = 9999999999
                const nbraccount = Math.floor(Math.random() * (max - min + 1)) + min;
                let today = todaysDateFormated();
                //Insertion dans la BDD du nouveau compte client
                const insert = await client.db('kkb').collection('clients').insertOne(
                    {
                        firstname_client:req.firstname_client,
                        lastName_client:req.lastName_client,
                        email_client:req.email_client,
                        password_client:req.password_client,
                        registrationDate_client:today,
                        gender_client:req.gender_client,
                        currentAccount_client:nbraccount
                    })
                //Insertion dans la BDD du nouveau compte courant affilié au client
                const insertaccount = await client.db('kkb').collection('current_account').insertOne(
                {
                    balance_current_account:10000,
                    floor_current_account:200,
                    account_number_current_account:nbraccount
                })
                msgsuccess="Bien enregistré ! Bienvenue "+req.gender_client+" "+req.lastName_client
                // console.log(msgsuccess)
                return msgsuccess ;
            } 
            else {
                msgerror="Vos 2 passwords sont différents"
                return msgerror
            }
        }
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return add(req);
}

//Récuperer les transactions d'un compte sur les 30 derniers jours quand le client se connecte
exports.getHistoAccount = (req) => {
    const client = new MongoClient(url);
// 1 Récupérer le compte client
    async function search(req){
        try{
            const database = client.db('kkb');
            const coll = database.collection('clients');
            const query = {email_client: req.email};
            const account = await coll.findOne(query); //Récupération du compte client
// 2 Vérifier que le password concorde
            if (req.password==account.password_client){
//3 Si oui, Récupérer les transactions en fonction du num de compte, mises dans un objet
                const transactions = database.collection('transactions');
                const transactionsarray = await transactions.find(
                    { account_transaction: account.currentAccount_client },
                    { _id: 0 }
                ).sort({ date_transaction: -1 }).toArray();

// 4 Retourner le tableau, avec seulement 30 jours
                let targetDate = new Date();   
                // --- set targetDate à aujourd'hui - n*jours 
                targetDate.setDate(targetDate.getDate() - 30-1);
                targetDate.setHours(0, 0, 0, 0);
                
                function padTo2Digits(num) {
                  return num.toString().padStart(2, '0');
                }
                
                function formatDate(date) {
                  return [
                    date.getFullYear(),
                    padTo2Digits(date.getMonth() + 1),
                    padTo2Digits(date.getDate()),
                  ].join('-');
                }
                let formatteddate = formatDate(targetDate);

                // Push chaque transaction après la target date dans l'array selectedTransactions
                let selectedTransactions = [];  
                for (let i = 0; i < transactionsarray.length; i++) {         
                    if (transactionsarray[i].date_transaction >= formatteddate){
                        selectedTransactions.push(transactionsarray[i]);
                    }
                }
            const currentaccount = database.collection('current_account');
            const query = {account_number_current_account: account.currentAccount_client};
            const currac = await currentaccount.findOne(query); //Récupération du compte client
                 
// 6 Pousser dans un tableau le compte client (index 0), les transactions (index 1) et le compte courant (index 2)
                let finaltab =[]
                finaltab.push(account)
                finaltab.push(selectedTransactions)
                finaltab.push(currac)
                // console.log(finaltab)
                return finaltab
            } else {
                let msgerror = "problème de connexion !"
                return msgerror
            }
        } 
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return search(req);
}


//Renvoi de l'objet admin :
// 1 Faire un query du bon objet
exports.getAdmin = (req) => {
    const client = new MongoClient(url);
    async function search(req){
        ref_admin = Number(req.email)
        password_admin = Number(req.password)
        // console.log(typeof(password_admin))
        try{
            const database = client.db('kkb');
            const coll = database.collection('admins');
            const query = {ref_admin: ref_admin};
            const account = await coll.findOne(query); //Récupération du compte admin
            // console.log(account)
// 2 Vérifier que le password concorde
            if (password_admin==account.password_admin){
// 3 Renvoyer l'objet demandé 
        // console.log(account)
        return account 
            }
        }
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return search(req)
} 

//Récuperer les comptes présentant une anomalie (solde négatif ou avec une transaction annulée)
exports.getAllPbCurrentAccounts = () => {
    const client = new MongoClient(url);
    async function search(){
        try{
            const database = client.db('kkb');
            const currentaccounts = database.collection('current_account');
//1 Récupérer tous les comptes courants 
            const currentaccountsarray = await currentaccounts.find().toArray();
//2 Pousser dans un tableau les soldes négatifs
            let negbalances =[]
            for(let i=0; i < currentaccountsarray.length ; i++) {
                if(currentaccountsarray[i].balance_current_account < 0) {
                    negbalances.push(currentaccountsarray[i])
                } 
            }
//3 Récupérer toutes les transactions annulées
            const wanted_coll = database.collection('transactions');
            const coll_promise = await wanted_coll.find({ canceled_transaction:true }).toArray();
//4 Dédoublonner le tableau
            const canceledtransac = coll_promise.reduce((accumulator, current) => {
                if (!accumulator.find((item) => item.account_transaction === current.account_transaction)) {
                  accumulator.push(current);
                }
                return accumulator;
              }, []);
//5 Pousser dans un tableau tous les comptes problématiques 
            let finalpbtab =[]
            finalpbtab.push(negbalances, canceledtransac) //Soldes négatifs index 0, transac annulées index 1
            return finalpbtab ;
        }
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return search();
}

// Récuperer les 10 dernières transactions
exports.get10NewTransac = () => {
    const client = new MongoClient(url);
    async function run(){
        try{
            const database = client.db('kkb');
            const wanted_coll = database.collection('transactions');
            const coll_promise = await wanted_coll.find().sort({date_transaction:-1}).limit(10).toArray();
            return coll_promise ;
        }
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return run();
}

// Récuperer les 10 derniers inscrits
exports.get10NewClients = () => {
    const client = new MongoClient(url);
    async function run(){
        try{
            const database = client.db('kkb');
            const wanted_coll = database.collection('clients');
            const coll_promise = await wanted_coll.find().sort({ registrationDate_client: -1 }).limit(10).toArray();
            return coll_promise ;
        }
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return run();
}

// Récuperer tous les comptes courants
exports.getAllCurrentAccounts = () => {
    const client = new MongoClient(url);
    async function run(){
        try{
            const database = client.db('kkb');
            const wanted_coll = database.collection('current_account');
            const coll_promise = await wanted_coll.find().sort({ balance_current_account: -1 }).toArray(); //Tri par solde
            return coll_promise ;
        }
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return run();
}

//Récupérer toutes les transac d'un compte sur 30 jours
exports.getAllFromAccount = (req) => {
    const client = new MongoClient(url);
// 1 Récupérer le compte client
    let nbraccount = Number(req.account_number_current_account)
    async function search(req){
        try{
            const database = client.db('kkb');
            const coll = database.collection('clients');
            const query = {currentAccount_client: nbraccount};
            const account = await coll.findOne(query); //Récupération du compte client
            // console.log(account)
//2 Récupérer les transactions en fonction du num de compte, mises dans un objet
            const transactions = database.collection('transactions');
            const transactionsarray = await transactions.find(
                { account_transaction: nbraccount },
                { _id: 0 }
            ).sort({ date_transaction: -1 }).toArray();
                // console.log(transactionsarray)

//2 Récupérer le compte courant
            const currentaccount = database.collection('current_account');
            const query2 = {account_number_current_account: nbraccount};
            const currac = await currentaccount.findOne(query2); //Récupération du compte client
                 
// 3 Pousser dans un tableau le compte client (index 0), les transactions (index 1) et le compte courant (index 2)
                let finaltab =[]
                finaltab.push(account)
                finaltab.push(transactionsarray)
                finaltab.push(currac)
                // console.log(finaltab[2])
                return finaltab
        } 
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return search(req);
}

//Fonction pour effectuer un virement
exports.doPayment = (req) => {
    const client = new MongoClient(url);
    async function search(req){
        let msg=""
        let newamount =""
        try{
            
            const database = client.db("kkb");
            const coll = database.collection("current_account");
            let accountnbr = Number(req.account_number_current_account_emitter)
            const query = { account_number_current_account: accountnbr };
            const account = await coll.findOne(query) //Récupération du compte
            const result = (Number(account.balance_current_account) + Number(req.amount)) //Simulation du résultat de l'opération
            let ok=true; // Variable de l'autorisation d'opération
            //Vérif si l'opération ne dépasse pas le découvert autorisé
            if (result >= account.floor_current_account){ 
                const updateDoc = {
                    $set: {
                        balance_current_account: result}
                    }
                const XXX = await coll.updateOne(query, updateDoc); // Si oui, on effectue l'opération
                msg = "Nouveau solde de votre compte "+accountnbr+" : "+result+" € "
                newamount = result
            }
            else { 
                ok=false // Si opération impossible, on renvoie un message d'erreur
                msg = "Impossible d'effectuer votre transaction, fonds insuffisants"
            }
            // Puis on crée la ligne dans la base "transactions"
            const coll2 = database.collection("transactions"); 
            let today = todaysDateFormated()
            let accountnbrereceiver = Number(req.account_number_current_account_receiver)
            const insert2 = await coll2.insertOne(
                {
                    beneficiary_transaction:accountnbrereceiver,
                    type_transaction:"Virement vers compte N° "+accountnbrereceiver,
                    amount_transaction:req.amount,
                    date_transaction:today,
                    canceled_transaction:ok,
                    account_transaction:accountnbr
                })

            //On ajoute le montant au compte bénéficiaire (si transaction autorisée)
            if (ok){ 
            const query2 = { account_number_current_account: accountnbrereceiver };
            const account2 = await coll.findOne(query2) //Récupération du compte
            const result2 = (Number(account2.balance_current_account) + Number(req.amount)) //Simulation du résultat de l'opération
            const updateDoc2 = {
                $set: {
                    balance_current_account: result2}
                }
            const newresult = await coll.updateOne(query2, updateDoc2); // On effectue l'opération

            // Puis on crée la ligne dans la base "transactions"
            const insert3 = await coll2.insertOne(
                {
                    beneficiary_transaction:accountnbrereceiver,
                    type_transaction:"Virement depuis compte N° "+accountnbr,
                    amount_transaction:Number(Math.abs(req.amount)),
                    date_transaction:today,
                    canceled_transaction:ok,
                    account_transaction:accountnbrereceiver
                }) 
            }
            //Renvoyer le msg d'erreur ou de succès
            
            let msg2 =  {msg:msg,
                        newamount:newamount,
            }
            console.log(msg2)
            return msg2
        }
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return search(req)
} 
   
//Fonction pour récup tous les comptes courants
exports.getAllCurrentAccounts = () => {
    const client = new MongoClient(url);

    async function run(){
        try{
            const database = client.db('kkb');
            const wanted_coll = database.collection('current_account');
            let mysort = { account_number_current_account : 1 }
            const coll_promise = await wanted_coll.find().sort(mysort).toArray();
            console.log(coll_promise)
            return coll_promise ;
        }
        catch { (err) => {
            if(err) console.log(err.message);
            }
        }
        finally {
            await client.close();
        }
    }
    return run();
}