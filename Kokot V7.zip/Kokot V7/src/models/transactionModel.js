const dbu = require('../db/db_utils');

exports.getPbTransactions = () => {
  return dbu.getAllPbCurrentAccounts();
}

exports.getTransactions = () => {
  return dbu.get10Transac();
}