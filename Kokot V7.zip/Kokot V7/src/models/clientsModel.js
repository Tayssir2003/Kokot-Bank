const dbu = require('../db/db_utils');
  
exports.modifytheAmount = (req) => {
  return dbu.updateAmount(req);
}

exports.addOneClient = (client) => {
  return dbu.addClient(client);
}

exports.connectOneClient = (client) => {
  return dbu.getHistoAccount(client);
}

exports.doAPayment = (req) => {
  return dbu.doPayment(req);
}