const dbu = require('../db/db_utils');

exports.connectOneAdmin = (admin) => {
  return dbu.getAdmin(admin);
}

exports.getAccountDetails = (account) => {
  return dbu.getAllFromAccount(account);
}

exports.getClients = () => {
  return dbu.get10NewClients();
}
  
exports.get10Transacs = () => {
  return dbu.get10NewTransac();
}

exports.getAllAccounts = () => {
  return dbu.getAllCurrentAccounts();
}
