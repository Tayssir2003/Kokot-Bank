const clientModel = require("../models/clientsModel");

//---------------------Signin--------------------
exports.signup = (req, res, next) => {
  let client = req.body;
  clientModel.addOneClient(client).then( Message => {
  res.render("pages/index", { Message });
})};

exports.connexion = (req, res, next) => {
  let client = req.body;
  clientModel.connectOneClient(client).then( clients => {
  res.render("pages/client_dashboard", { clients });
})};

//---------------------Opérations sur le compte--------------------
exports.modifyAmount = (req, res, next) => {
  let client = req.body;
  clientModel.modifytheAmount(client).then( message => {
  res.send(message)
  }
)};

exports.doPayment = (req, res, next) => {
  let client = req.body;
  clientModel.doAPayment(client).then( message => {
    res.send(message)
  }
)};
