const currentAccountModel = require("../models/transactionModel");

//afficher les 30 transactions d'un compte
exports.getAllTransactions = (req, res, next) => {
  transactionModel.getTransactions().then( transactions => {
  res.render("pages/accountTransactions", { transactions });
});
};

//afficher les comptes courants qui ont des anomalies pour l'admin
exports.displayAccountsAnomalies = (req, res, next) => {
  currentAccountModel.getPbTransactions().then( transactions => {
  res.send(transactions);
});
};




