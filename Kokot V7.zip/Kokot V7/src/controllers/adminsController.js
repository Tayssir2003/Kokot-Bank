const adminModel = require("../models/adminModel");

exports.connexion = (req, res, next) => {
  let admin = req.body;
  adminModel.connectOneAdmin(admin).then( admins => {
  res.render("pages/admin_dashboard", { admins });
})};

exports.getAnAccount = (req, res, next) => {
  let client = req.body;
  adminModel.getAccountDetails(client).then( message => {
    res.send(message)
  }
)};

exports.getAllClients = (req, res, next) => {
  adminModel.getClients().then( clients => {
    res.send(clients)
});
};

exports.getTransacs = (req, res, next) => {
  adminModel.get10Transacs().then( transacs => {
    res.send(transacs)
});
};

exports.getAccounts = (req, res, next) => {
  adminModel.getAllAccounts().then( accounts => {
    res.send(accounts)
});
};

