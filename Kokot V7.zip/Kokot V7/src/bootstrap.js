// import the routes module 
route = require("./routes")
// exports the custom routes module with proper routes 
module.exports = (app,router) => {
    route.appRoute(router);
}