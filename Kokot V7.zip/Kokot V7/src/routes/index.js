const { application } = require('express');

clientsController = require('../controllers/clientsController');
adminsController = require('../controllers/adminsController');
transactionsController = require('../controllers/transactionsController');

exports.appRoute = router => {
    //-----------signupClient----------------
   router.post("/addClient", clientsController.signup );//OK //  pour ajouter un client

    //-----------signinClient----------------
    router.post("/clientConnexion", clientsController.connexion );//OK //connexion d'un client

    //-----------signinAdmin-------------------
   router.post("/adminConnexion", adminsController.connexion );//OK //connexion d'un admin

    //-----------dashboardClient----------------
    router.get("/accountTransactions", transactionsController.getAllTransactions );//OK //afficher les 30 transactions d'un compte
    router.post("/modifyAmount", clientsController.modifyAmount );//OK //connexion d'un client//Effectuer une modif de montant : achat / Versement
    router.post("/payment", clientsController.doPayment );//OK //connexion d'un client//Effectuer une modif de montant : achat / Versement// Effectuer un virement
    //-----------dashboardAdmin----------------
    router.post("/getAccountDetails", adminsController.getAnAccount );//OK//afficher les détails d'un compte
    router.get("/accountsAnomalies", transactionsController.displayAccountsAnomalies );//OK //afficher les comptes courants qui on des anomalies pour l'admin
    router.get("/tenLatestClients", adminsController.getAllClients );//OK //afficher les 10 derniers clients
    router.get("/tenLatestTransactions", adminsController.getTransacs );//OK //afficher les 10 dernieres transac
    router.get("/AllAccounts", adminsController.getAccounts );//OK 
   }
