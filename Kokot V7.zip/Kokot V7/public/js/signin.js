//CONNEXION SELECT BUTTONS MANAGEMENT

const clientButton = document.getElementById('clientConnexion');
const adminButton = document.getElementById('adminConnexion');
const signUpInfos = document.getElementById('signupCard');
const connexionForm = document.getElementById('connexionForm');
const signupMethod = document.getElementById('email');
const emailLabel = document.getElementById('emailLabel')


function clientButtonClicked() {
    
    adminButton.setAttribute('selectedConnexionType', 'false');
    clientButton.setAttribute('selectedConnexionType', 'true');
    connexionForm.setAttribute('action', '/clientConnexion')
    signupMethod.setAttribute('type', 'email');
    signupMethod.setAttribute('placeholder', 'adresse@email.com')
    emailLabel.innerHTML = "Adresse e-mail";


    
    signUpInfos.innerHTML = `
    <p> Pas encore de compte ? Inscrivez vous ! </p>
                <br>
                <form method="GET" action="/signup">
                    <button type="submit">Inscription</button>
                </form>

    `
}

function adminButtonClicked() {
    adminButton.setAttribute('selectedConnexionType', 'true');
    clientButton.setAttribute('selectedConnexionType', 'false');
    connexionForm.setAttribute('action', '/adminConnexion')
    signupMethod.setAttribute('type', 'text');
    signupMethod.setAttribute('placeholder', 'Ref admin')
    emailLabel.innerHTML = "Référence admin :"
    
    signUpInfos.innerHTML="";

}

clientButton.addEventListener('click', clientButtonClicked)
adminButton.addEventListener('click', adminButtonClicked)


// REMPLIT AUTOMATIQUEMENT LA VALUE DU FORM DATE AVEC LA DATE DU JOUR

todaysDate = new Date();
const dateInput = document.getElementById('dateInput');
dateInput.setAttribute('value', todaysDate);