// ----- DONNES DANS client_dashboard_dataStorage ----- //
// Les transactions des 30 derniers jours = transactionHistoryCurrentAccount
// Les data du client qui s'est connecté = clientInfo
// Les data du compte courrant = current_account_info
console.log(transactionHistoryCurrentAccount);

// ---- REMPLISSAGE DES INFORMATIONS CLIENT ---- //

document.getElementById("client_lastConnexionDate").innerHTML =`${clientInfo.lastConnexionDate_client.getDate()}/${clientInfo.lastConnexionDate_client.getMonth()}/${clientInfo.lastConnexionDate_client.getFullYear()}`;
document.getElementById("client_registrationDate").innerHTML=`${clientInfo.registrationDate_client.getDate()}/${clientInfo.registrationDate_client.getMonth()}/${clientInfo.registrationDate_client.getFullYear()}`;
document.getElementById("account_balance").innerHTML = `${current_account_info.balance_current_account.toFixed(2)} €`;
if (clientInfo.gender_client = "Mme.") {document.getElementById("addAnE").innerHTML = 'e'};


// si balance > 0 set la classe à positibeNB, si la balance < 0 set la classe à negativeNB
function displayAccountBalace(amountOnAccount){
  if (amountOnAccount > 0 ) {
          document.getElementById("account_balance").setAttribute('class', 'positiveNb')
        } else {
          document.getElementById("account_balance").setAttribute('class', 'negativeNb')
  }
}

displayAccountBalace(current_account_info.balance_current_account);
// FONCTION QUI PERMET DE SELECTIONNER LES TRANSACTIONS DEPUIS n JOURS ET LES STOCKE DANS UN ARRAY
// Arguments : le nombre de jours à afficher / le nom de l'array contenant les transaction
// Retourne : un array avec toutes les transactions depuis n jours
function getTransactionsFromNDaysAgo(days, transactions){
    
    // --- set targetDate à aujourd'hui
    let targetDate = new Date();                       
    
    // --- set targetDate à aujourd'hui - n*jours 
    targetDate.setDate(targetDate.getDate() - days-1);              

    // --- crée un array selectedTransactions dans lequel on stockera les transactions
    let selectedTransactions = [];                                  

    // --- pour chaque transactions, vérifie si elle a bien lieu après la date choisie et la stocke dans  l'array selectedTransactions
    for (let i = 0; i < transactions.length; i++) {                 

        if (transactions[i].date_transaction >= targetDate){
            selectedTransactions.push(transactions[i]);
        }

    }

    // --- retourne les selectedTransactions sous forme de tableau
    return selectedTransactions;                                    

};


// ---- REMPLISSAGE DU TABLEAU DE L'HISTORIQUE DES TRANSACTIONS ---- //
function displayTransactionsHistory(days, tableId ){

    const historyTable = document.getElementById(tableId);

    historyTable.innerHTML = ` <div class="transactionDisplayHeader"> <p>Transaction</p> <p>Montant</p> <p>Compte</p> </div>`;

    let transactionArray = getTransactionsFromNDaysAgo(days, transactionHistoryCurrentAccount);

    for (let t = 0; t < transactionArray.length; t++) {

        let validationHTML = ``;
        if (transactionArray[t].canceled_transaction === true) {
                validationHTML = `<p class="validation negativeNb" > Annulé <img src="resources/circle-xmark-solid.svg"/> </p>`
        } else {validationHTML = `<p class="validation positiveNb" > Validé <img src="resources/circle-check-solid.svg"/> </p>`}

        let amountHTML = ``;
        if (transactionArray[t].amount_transaction > 0) {
                amountHTML = `<p class="ammount positiveNb">${transactionArray[t].amount_transaction}€</p>`
        } else {amountHTML = `<p class="ammount negativeNb">${transactionArray[t].amount_transaction.toFixed(2)}€</p>`}

        let dateHTML = `<p class="date">${transactionArray[t].date_transaction.getDate()}/${(transactionArray[t].date_transaction.getMonth()+1)}/${transactionArray[t].date_transaction.getFullYear()}</p>`;

        

        historyTable.innerHTML += `
        <div class="transactionDisplay">
            <p class="beneficiary">${transactionArray[t].beneficiary_transaction}</p>
            <p class="type">${transactionArray[t].type_transaction}</p>
            ${amountHTML}
            ${dateHTML}
            ${validationHTML}
            <p class="account">${transactionArray[t].account_transaction}</p>
        </div>`
        
    };
};


// FONCTION QUI PERMET LES OPERATIONS + ET - POUR LES DATE
Date.prototype.addDays = function(days) {
  var date = new Date(this.valueOf());
  date.setDate(date.getDate() + days);
  return date;
}


// FONCTION QUI TRIE TOUTES LES OPERATIONS DEPUIS n JOURS ET LES STOCKE DANS UN ARRRAY Où 1 index = 1 jour
// Arguments : le nombre de jours à afficher / le nom de l'array contenant les transactions
// Retourne : un tableau des montants des transactions où 1 index = 1 jour (/!\ un index peut contenir plusieurs ou aucune opération)

function getAmmountsForEachDay(days, transactions){

  // crée un array dayByDayTransactions dans lequel seront stockés les résultats
  let dayByDayTransactions = [];

  // la variable checkDate est initiée au jour à partir duquel on veut récupérer les résultats
  let checkDate = new Date().addDays(-days);

  // Pour chaque jours : 
  for (let d = 0; d < days; d++) {

    // crée un index / jour dans l'array dayByDayTransactions 
    dayByDayTransactions.push([]);

    // Pour chaque transactions
    for (let i = 0; i < transactions.length; i++) {
        
        // Vérifie si le jour, le mois et l'année correspondent à checkDate
        if (
             transactions[i].date_transaction.getYear() === checkDate.getYear() 
          && transactions[i].date_transaction.getMonth() === checkDate.getMonth() 
          && transactions[i].date_transaction.getDate() === checkDate.getDate()) 
        {
          // Si oui, ajoute le montant de la transaction au tableau dayByDayTransactions à l'index correspondant à ce jour
          dayByDayTransactions[d].push(transactions[i].amount_transaction);
            
        }
      
    }
    // Ajoute 1 jour à checkDate pour vérifier le jour suivant
    checkDate = checkDate.addDays(1);

  }

  // Retourne un tableau des montants des transactions où 1 index = 1 jour
  return dayByDayTransactions;
}

// FONCTION QUI CALCULE LE TOTAL DES TRANSACTIONS POUR CHAQUE JOUR ET LES STOCKE DANS UN ARRAY Où 1 index = 1 jour
// PUIS CALCULE QUEL ETAIT LE MONTANT SUR LE COMPTE POUR CHAQUE JOURS EN PARTANT DU MONTANT ACTUEL
// Arguments : le nombre de jours à afficher / le nom de l'array contenant les transactions
// Retourne : un tableau où 1 index = total des transactions d'une journée
function getBalanceForEachDay(days, transactionsInput, currentBalanceOnAccount) {

  // Récupère un tableau des montants des transactions pour chaque jour
  let transactions = getAmmountsForEachDay(days, transactionsInput);

  // Crée un array qui stockera le total des transactions de chaque jours où 1 index = 1 jour
  let balanceForEachDay = [];

  // Pour chaque jour, ajoute le montant de toutes les transactions de cette journée et le stocke dans balanceForEachDay
  for (let t = 0; t < transactions.length; t++) {
      let currentDayBalance = 0;
      for (let i = 0; i < transactions[t].length; i++) {
        currentDayBalance += Number(transactions[t][i]);
        
      }
      balanceForEachDay.push(Number(currentDayBalance.toFixed(2)));
  }

  // crée un array qui fini par le montant actuel sur le compte
  let actualBalance = [currentBalanceOnAccount];

  // crée la variable currentBalance qui commence avec comme valeur le montant actuel sur le compte
  let currentBalance = currentBalanceOnAccount;

  // Pour chaque jour, calcule quel était le montant sur le compte pour chaque jour en prenant en compte les transactions
  for (let f = balanceForEachDay.length; f > 0 ; f--) {
    currentBalance -= balanceForEachDay[f-1];
    actualBalance.unshift(currentBalance.toFixed(2));
  }


  return actualBalance;

}


// FUNCTION QUI CREE UN TABLEAU AVEC LES DATES DES n DERNIERS JOURS
function dateTable(days){
    let checkDate = new Date().addDays(-days);
    let dateArray = [];
    for (let i = 0; i < days+1; i++) {
        dateArray.push(`${checkDate.getDate()}/${(checkDate.getMonth()+1)}`)
        checkDate = checkDate.addDays(+1);
    }
    return dateArray;
}


function generateChart(days, idOfChart){
  new Chart(idOfChart, {
    type: "line",
    data: {
        labels: dateTable(days),
        datasets: [{
        data: getBalanceForEachDay(days, transactionHistoryCurrentAccount, current_account_info.balance_current_account),
        tension: 0.1,
        borderColor: "DarkOrange",
        fill: false
        }]
    },
      options: {
        legend: {display: false}
      }
    });
}

// // ---- CODE QUI S'EXECUTE ----- // 

displayTransactionsHistory(5,'historyDisplayTable');
generateChart(5,'transactionsChart');





