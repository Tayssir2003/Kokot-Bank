
// FONCTION QUI PERMET DE CONVERTIR LES INFOS RECUES AU FORMAT HTML EN ARRAY
var decodeHtmlEntity = function(x) {
  return x.replace(/&#(\d+);/g, function(match, dec) {
    return String.fromCharCode(dec);
  });
};


// IMPORTER LES TRANSACTIONS
let transactionHistoryCurrentAccount = '';

function setimportedTransactions(info){
  transactionHistoryCurrentAccount = JSON.parse(decodeHtmlEntity(info)).map(obj => { return {...obj, date_transaction: new Date(obj.date_transaction)};});
}



// IMPORTER LES INFORMATIONS CLIENT
let clientInfo = [];

function setclientInfo(info){
clientInfo = [ JSON.parse(decodeHtmlEntity(info)) ].map(obj => { return {...obj, lastConnexionDate_client: new Date(obj.lastConnexionDate_client)};});
clientInfo = clientInfo.map(obj => { return {...obj, registrationDate_client: new Date(obj.registrationDate_client)};})[0];                                                              
}


// IMPORTER LES INFORMATIONS DU COMPTE CLIENT
let current_account_info = [];

function setcurrent_account_info(info){
  current_account_info = [ JSON.parse(decodeHtmlEntity(info)) ][0];                              
}

