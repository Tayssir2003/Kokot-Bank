// Les data de l'admin connecté                                     (à remplacer)
const adminInfo = [{
  "ref_admin": 23885,
  "gender_admin": "M.",
  "lastName_admin": "Enstein",
  "firstName_admin": "Frank",
  "lastConnexionDate_admin": "2023-12-14"
}].map(obj => { return {...obj, lastConnexionDate_admin: new Date(obj.lastConnexionDate_admin)};})[0];                                

// // Les 10 dernières transactions sur tous les comptes               (à remplacer)
const last10transactions = [{
  "beneficiary_transaction": "CARREFOUR",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -8.9,
  "date_transaction": "2023-12-15",
  "canceled_transaction": false,
  "account_transaction": 1000000016
},
{
  "beneficiary_transaction": "LA BANQUE POSTALE ASSURANCES IARD",
  "type_transaction": "Prelevement",
  "amount_transaction": -8.52,
  "date_transaction": "2023-12-15",
  "canceled_transaction": false,
  "account_transaction": 1000000005
},
{
  "beneficiary_transaction": "LA DISTILLERIE",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -6,
  "date_transaction": "2023-12-15",
  "canceled_transaction": false,
  "account_transaction": 1000000015
},
{
  "beneficiary_transaction": "CARREFOUR",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -34.89,
  "date_transaction": "2023-12-15",
  "canceled_transaction": false,
  "account_transaction": 1000000012
},
{
  "beneficiary_transaction": "MANCHESTER CAFE34MONTPELLIER",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -4,
  "date_transaction": "2023-12-15",
  "canceled_transaction": false,
  "account_transaction": 1000000006
},
{
  "beneficiary_transaction": "FREEBOX",
  "type_transaction": "Prelevement",
  "amount_transaction": -34.99,
  "date_transaction": "2023-12-15",
  "canceled_transaction": false,
  "account_transaction": 1000000014
},
{
  "beneficiary_transaction": "DELIVEROO FRANCE SAS",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -36.92,
  "date_transaction": "2023-12-15",
  "canceled_transaction": false,
  "account_transaction": 1000000008
},
{
  "beneficiary_transaction": "PISTACHE ET CHOCOLAT",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -8.8,
  "date_transaction": "2023-12-15",
  "canceled_transaction": false,
  "account_transaction": 1000000014
},
{
  "beneficiary_transaction": "GARE SNCF",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -7.7,
  "date_transaction": "2023-12-15",
  "canceled_transaction": false,
  "account_transaction": 1000000019
},
{
  "beneficiary_transaction": "www.lepetitvapo50325 C rue de",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -31.2,
  "date_transaction": "2023-12-15",
  "canceled_transaction": false,
  "account_transaction": 1000000015
}].map(obj => { return {...obj, date_transaction: new Date(obj.date_transaction)};});                        

// // Les comptes problématiques : où il y a un solde négatif          (à remplacer)
const accountWithProblemNegativeBalance = [{
  "balance_current_account": -1711.24,
  "floor_current_account": -3000,
  "account_number_current_account": 1000000011
},
{
  "balance_current_account": -1510.45,
  "floor_current_account": -4000,
  "account_number_current_account": 1000000010
},
{
  "balance_current_account": -740.12,
  "floor_current_account": -4000,
  "account_number_current_account": 1000000015
},
{
  "balance_current_account": -560.78,
  "floor_current_account": -2000,
  "account_number_current_account": 1000000016
},
{
  "balance_current_account": -426.2,
  "floor_current_account": -2000,
  "account_number_current_account": 1000000013
},
{
  "balance_current_account": -178.95,
  "floor_current_account": -100,
  "account_number_current_account": 1000000005
},
{
  "balance_current_account": -86.25,
  "floor_current_account": -1000,
  "account_number_current_account": 1000000008
}];             

// // Les comptes problématiques : où une transactions a été canceled  (à remplacer)
const accountWithProblemCanceledTransaction = [{
  "beneficiary_transaction": "PAYPAL",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -4.99,
  "date_transaction": "2023-12-15",
  "canceled_transaction": true,
  "account_transaction": 1000000014
},
{
  "beneficiary_transaction": "MLLE JEAN DUPONT",
  "type_transaction": "Virement",
  "amount_transaction": -90,
  "date_transaction": "2023-12-14",
  "canceled_transaction": true,
  "account_transaction": 1000000003
},
{
  "beneficiary_transaction": "BEC Immobilier",
  "type_transaction": "Virement",
  "amount_transaction": -304,
  "date_transaction": "2023-12-12",
  "canceled_transaction": true,
  "account_transaction": 1000000013
},
{
  "beneficiary_transaction": "M-TICKET TAM FR MONTPELLIER",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -10,
  "date_transaction": "2023-12-11",
  "canceled_transaction": true,
  "account_transaction": 1000000017
},
{
  "beneficiary_transaction": "BROC'CAFE",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -3.5,
  "date_transaction": "2023-12-08",
  "canceled_transaction": true,
  "account_transaction": 1000000005
},
{
  "beneficiary_transaction": "DISCORD NITROCUS HTTPSDISCORD",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -5.09,
  "date_transaction": "2023-12-08",
  "canceled_transaction": true,
  "account_transaction": 1000000014
},
{
  "beneficiary_transaction": "THE BLACK SHEEP",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -2.5,
  "date_transaction": "2023-12-06",
  "canceled_transaction": true,
  "account_transaction": 1000000010
},
{
  "beneficiary_transaction": "THE BLACK SHEEP",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -4.5,
  "date_transaction": "2023-12-05",
  "canceled_transaction": true,
  "account_transaction": 1000000019
},
{
  "beneficiary_transaction": "SARL BEC IMMOBILIER",
  "type_transaction": "Virement",
  "amount_transaction": -290,
  "date_transaction": "2023-12-04",
  "canceled_transaction": true,
  "account_transaction": 1000000013
},
{
  "beneficiary_transaction": "C & A",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -106.12,
  "date_transaction": "2023-12-03",
  "canceled_transaction": true,
  "account_transaction": 1000000019
},
{
  "beneficiary_transaction": "MANCHESTER CAFE34MONTPELLIER",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -8.4,
  "date_transaction": "2023-12-02",
  "canceled_transaction": true,
  "account_transaction": 1000000015
},
{
  "beneficiary_transaction": "THE BLACK SHEEP",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -7,
  "date_transaction": "2023-12-02",
  "canceled_transaction": true,
  "account_transaction": 1000000019
},
{
  "beneficiary_transaction": "C & A",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -87.19,
  "date_transaction": "2023-11-29",
  "canceled_transaction": true,
  "account_transaction": 1000000018
},
{
  "beneficiary_transaction": "MANCHESTER CAFE34MONTPELLIER",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -7.5,
  "date_transaction": "2023-11-29",
  "canceled_transaction": true,
  "account_transaction": 1000000007
},
{
  "beneficiary_transaction": "STEAMGAMES.COM DEDE HAMBURG",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -29.98,
  "date_transaction": "2023-11-27",
  "canceled_transaction": true,
  "account_transaction": 1000000000
},
{
  "beneficiary_transaction": "THE BLACK SHEEP",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -11.5,
  "date_transaction": "2023-11-26",
  "canceled_transaction": true,
  "account_transaction": 1000000013
},
{
  "beneficiary_transaction": "CARREFCITYSCO FR MONTPELLIER",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -27.78,
  "date_transaction": "2023-11-25",
  "canceled_transaction": true,
  "account_transaction": 1000000006
},
{
  "beneficiary_transaction": "CARREFCITYSCO FR MONTPELLIER",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -10.27,
  "date_transaction": "2023-11-23",
  "canceled_transaction": true,
  "account_transaction": 1000000000
},
{
  "beneficiary_transaction": "LBP IARD",
  "type_transaction": "Prelevement",
  "amount_transaction": -5.51,
  "date_transaction": "2023-11-22",
  "canceled_transaction": true,
  "account_transaction": 1000000013
},
{
  "beneficiary_transaction": "FRAIS BANCAIRES",
  "type_transaction": "Frais bancaires",
  "amount_transaction": -12,
  "date_transaction": "2023-11-21",
  "canceled_transaction": true,
  "account_transaction": 1000000016
},
{
  "beneficiary_transaction": "EURO VIR CAF DE L HERAULT",
  "type_transaction": "Virement recu",
  "amount_transaction": 177.7,
  "date_transaction": "2023-11-19",
  "canceled_transaction": true,
  "account_transaction": 1000000001
},
{
  "beneficiary_transaction": "PISTACHE ET CHOCOLAT",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -2.9,
  "date_transaction": "2023-11-19",
  "canceled_transaction": true,
  "account_transaction": 1000000009
},
{
  "beneficiary_transaction": "CARREFOUR FRANC75PARIS",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -26.75,
  "date_transaction": "2023-11-17",
  "canceled_transaction": true,
  "account_transaction": 1000000006
},
{
  "beneficiary_transaction": "BAMBOUSERAIE",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -5,
  "date_transaction": "2023-11-17",
  "canceled_transaction": true,
  "account_transaction": 1000000006
},
{
  "beneficiary_transaction": "CARREFOUR FRANC75PARIS",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -38.95,
  "date_transaction": "2023-11-17",
  "canceled_transaction": true,
  "account_transaction": 1000000009
},
{
  "beneficiary_transaction": "THE BEEHIVE",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -28.1,
  "date_transaction": "2023-11-15",
  "canceled_transaction": true,
  "account_transaction": 1000000013
},
{
  "beneficiary_transaction": "C.P.A.M. DE L.HERAULT",
  "type_transaction": "Virement recu",
  "amount_transaction": 25,
  "date_transaction": "2023-11-15",
  "canceled_transaction": true,
  "account_transaction": 1000000008
},
{
  "beneficiary_transaction": "FIGUREDART PARIS",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -65.7,
  "date_transaction": "2023-11-10",
  "canceled_transaction": true,
  "account_transaction": 1000000012
},
{
  "beneficiary_transaction": "Google Payment IE Dublin",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -1.99,
  "date_transaction": "2023-11-07",
  "canceled_transaction": true,
  "account_transaction": 1000000015
},
{
  "beneficiary_transaction": "COTISATIONS BANCAIRES",
  "type_transaction": "Frais bancaires",
  "amount_transaction": -2,
  "date_transaction": "2023-11-06",
  "canceled_transaction": true,
  "account_transaction": 1000000017
},
{
  "beneficiary_transaction": "BDA DISTRIBUTION",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -0.6,
  "date_transaction": "2023-11-03",
  "canceled_transaction": true,
  "account_transaction": 1000000007
},
{
  "beneficiary_transaction": "MANCHESTER CAFE34MONTPELLIER",
  "type_transaction": "Carte bancaire",
  "amount_transaction": -4,
  "date_transaction": "2023-11-01",
  "canceled_transaction": true,
  "account_transaction": 1000000003
}].map(obj => { return {...obj, date_transaction: new Date(obj.date_transaction)};});     
   

// Les 10 derniers clients inscrits                                 (à remplacer)
const last10Clients = [{
  "gender_client": "Mme.",
  "lastName_client": "Tonin",
  "firstName_client": "Sarah",
  "registrationDate_client": "2023-08-16",
  "currentAccount_client": 1000000019
},
{
  "gender_client": "M.",
  "lastName_client": "Bow",
  "firstName_client": "Harry",
  "registrationDate_client": "2023-08-11",
  "currentAccount_client": 1000000018
},
{
  "gender_client": "Mme.",
  "lastName_client": "Lies",
  "firstName_client": "Anna",
  "registrationDate_client": "2023-05-30",
  "currentAccount_client": 1000000017
},
{
  "gender_client": "M.",
  "lastName_client": "Free",
  "firstName_client": "Phill",
  "registrationDate_client": "2023-02-06",
  "currentAccount_client": 1000000016
},
{
  "gender_client": "Mme.",
  "lastName_client": "Pole",
  "firstName_client": "Lou",
  "registrationDate_client": "2023-01-30",
  "currentAccount_client": 1000000015
},
{
  "gender_client": "M.",
  "lastName_client": "Sleigh",
  "firstName_client": "Bob",
  "registrationDate_client": "2023-01-23",
  "currentAccount_client": 1000000014
},
{
  "gender_client": "Mme.",
  "lastName_client": "Krystal",
  "firstName_client": "Krystal",
  "registrationDate_client": "2022-01-02",
  "currentAccount_client": 1000000013
},
{
  "gender_client": "M.",
  "lastName_client": "Fabet",
  "firstName_client": "Al",
  "registrationDate_client": "2021-04-11",
  "currentAccount_client": 1000000012
},
{
  "gender_client": "Mme.",
  "lastName_client": "Thrax",
  "firstName_client": "Ann",
  "registrationDate_client": "2020-09-28",
  "currentAccount_client": 1000000011
},
{
  "gender_client": "M.",
  "lastName_client": "Cade",
  "firstName_client": "Barry",
  "registrationDate_client": "2020-08-01",
  "currentAccount_client": 1000000010
}].map(obj => { return {...obj, registrationDate_client: new Date(obj.registrationDate_client)};});                            


// Le solde de tous les comptes courrants et leur numero            (à remplacer)   
const allAccountsBalance = [{
    "balance_current_account": -1711.24,
    "account_number_current_account": 1000000011
  },
  {
    "balance_current_account": -1510.45,
    "account_number_current_account": 1000000010
  },
  {
    "balance_current_account": -740.12,
    "account_number_current_account": 1000000015
  },
  {
    "balance_current_account": -560.78,
    "account_number_current_account": 1000000016
  },
  {
    "balance_current_account": -426.2,
    "account_number_current_account": 1000000013
  },
  {
    "balance_current_account": -178.95,
    "account_number_current_account": 1000000005
  },
  {
    "balance_current_account": -86.25,
    "account_number_current_account": 1000000008
  },
  {
    "balance_current_account": 334.12,
    "account_number_current_account": 1000000017
  },
  {
    "balance_current_account": 420.56,
    "account_number_current_account": 1000000002
  },
  {
    "balance_current_account": 793.67,
    "account_number_current_account": 1000000018
  },
  {
    "balance_current_account": 825.74,
    "account_number_current_account": 1000000019
  },
  {
    "balance_current_account": 1071.52,
    "account_number_current_account": 1000000009
  },
  {
    "balance_current_account": 1110.44,
    "account_number_current_account": 1000000001
  },
  {
    "balance_current_account": 1123.72,
    "account_number_current_account": 1000000004
  },
  {
    "balance_current_account": 1230.12,
    "account_number_current_account": 1000000012
  },
  {
    "balance_current_account": 1445.75,
    "account_number_current_account": 1000000000
  },
  {
    "balance_current_account": 1497.14,
    "account_number_current_account": 1000000014
  },
  {
    "balance_current_account": 1506.97,
    "account_number_current_account": 1000000006
  },
  {
    "balance_current_account": 1510.45,
    "account_number_current_account": 1000000007
  },
  {
    "balance_current_account": 1899.87,
    "account_number_current_account": 1000000003
  }];                       