document.getElementById("admin_gender").innerHTML = adminInfo.gender_admin;
document.getElementById("admin_lastName").innerHTML = adminInfo.lastName_admin;
document.getElementById("admin_firstName").innerHTML = adminInfo.firstName_admin;
document.getElementById("admin_lastConnexionDate").innerHTML =`${adminInfo.lastConnexionDate_admin.getDate()}/${adminInfo.lastConnexionDate_admin.getMonth()}/${adminInfo.lastConnexionDate_admin.getFullYear()}`;
document.getElementById("admin_ref").innerHTML = adminInfo.ref_admin;



let balaceArray = [];
let accountNbArray = [];

for (let b = 0; b < allAccountsBalance.length; b++) {
    balaceArray.push(allAccountsBalance[b].balance_current_account)
    accountNbArray.push(allAccountsBalance[b].account_number_current_account)
}

const xValues = accountNbArray;
const yValues = balaceArray;
const colours = yValues.map((value) => value < 0 ? '#DE6164' : '#15B988');


new Chart("allBalanceChart", {
  type: "bar",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: colours,
      data: yValues
    }]
  },
  options: {
    legend: {display: false}
  }
});



function displayTransactionsHistory(tableId, transactions ){

  const historyTable = document.getElementById(tableId);

  historyTable.innerHTML = ` <div class="transactionDisplayHeader"> <p>Transaction</p> <p>Montant</p> <p>Compte</p> </div>`;

  let transactionArray = transactions;

  for (let t = 0; t < transactionArray.length; t++) {

      let validationHTML = ``;
      if (transactionArray[t].canceled_transaction === true) {
              validationHTML = `<p class="validation negativeNb" > Annulé <img src="resources/circle-xmark-solid.svg"/> </p>`
      } else {validationHTML = `<p class="validation positiveNb" > Validé <img src="resources/circle-check-solid.svg"/> </p>`}

      let amountHTML = ``;
      if (transactionArray[t].amount_transaction > 0) {
              amountHTML = `<p class="ammount positiveNb">${transactionArray[t].amount_transaction}€</p>`
      } else {amountHTML = `<p class="ammount negativeNb">${transactionArray[t].amount_transaction.toFixed(2)}€</p>`}

      let dateHTML = `<p class="date">${transactionArray[t].date_transaction.getDate()}/${transactionArray[t].date_transaction.getMonth()}/${transactionArray[t].date_transaction.getFullYear()}</p>`;

      

      historyTable.innerHTML += `
      <div class="transactionDisplay">
          <p class="beneficiary">${transactionArray[t].beneficiary_transaction}</p>
          <p class="type">${transactionArray[t].type_transaction}</p>
          ${amountHTML}
          ${dateHTML}
          ${validationHTML}
          <p class="account">${transactionArray[t].account_transaction}</p>
      </div>`
      
  };
};

displayTransactionsHistory('historyDisplayTableLast10Transactions', last10transactions );
displayTransactionsHistory('problematicAccountsCanceledTransaction',  accountWithProblemCanceledTransaction);