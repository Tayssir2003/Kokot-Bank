// BUTTONS
const virementButton = document.getElementById("virementButton");
const acceuilButton = document.getElementById("acceuilButton");

// DIVS TO DISPLAY OR HIDE
const mainContainer = document.getElementById("mainContainer");
const welcomeMessage = document.getElementById("welcomeMessage");
const currentBalance = document.getElementById("currentBalance");
const graphBalance = document.getElementById("graphBalance");
const historyDetail = document.getElementById("historyDetail");
const virementsBlock = document.getElementById('Virements');

function displayAcceuil(noneOrblock){
    graphBalance.style.display= noneOrblock;
    historyDetail.style.display= noneOrblock;
}
function displayVirement(noneOrblock){
    virementsBlock.style.display= noneOrblock;
}


function acceuilButtonScript(){
    displayAcceuil("block");
    displayVirement("none");
}

function virementButtonScript(){
    displayAcceuil("none");
    displayVirement("block");
}