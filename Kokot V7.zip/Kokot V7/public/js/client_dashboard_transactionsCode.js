var form=document.getElementById('form')
form.addEventListener('submit', function(e){
    e.preventDefault()

    var type_transaction = document.getElementById('type_transaction2').value
    var amount=document.getElementById('amount2').value
    var beneficiary_transaction=document.getElementById('beneficiary_transaction2').value
    var account_number_current_account=document.getElementById('account_number_current_account2').value
    
    fetch('/modifyAmount', {
        method: 'POST',
        body: JSON.stringify({
            amount:amount,
            beneficiary_transaction:beneficiary_transaction,
            type_transaction:type_transaction,
            account_number_current_account:account_number_current_account,
        }),
        headers: {
        'Content-type': 'application/json; charset=UTF-8',
        }
    })
    .then(function(response){ 
        return response.text()})
    .then(function(data){
        console.log(data)
        display=document.getElementById("display")
        display.innerText = data
    })  
    .catch(error => console.error('Error:', error)); 
});


/////////////////Fonction pour le virement/////////////////////////

var payment=document.getElementById('payment')
payment.addEventListener('submit', function(e){
    e.preventDefault()
    var account_number_current_account_receiver = document.getElementById('account_number_current_account_receiver').value
    var amount=document.getElementById('amount').value
    var account_number_current_account_emitter=document.getElementById('account_number_current_account_emitter').value

    fetch('/payment', {
        method: 'POST',
        body: JSON.stringify({
            amount:(Math.abs(amount) * -1),
            account_number_current_account_receiver:account_number_current_account_receiver,
            account_number_current_account_emitter:account_number_current_account_emitter,
        }),
        headers: {
            'Content-type': 'application/json; charset=UTF-8',
        }
    })
    .then(function(response){ 
        return response.json()})
    .then(function(data){
        console.log(data)
        display=document.getElementById("display")
        displaybalance=document.getElementById("account_balance")
        displaybalance.innerText = `${data.newamount}€`
        display.innerText = data.msg
        displayAccountBalace(data.newamount);
    })

    .then(function(response){ 
        return response.text()})
    .then(function(data){
        console.log(data)
        display=document.getElementById("display")
        display.innerText = data
    })  





    .catch(error => console.error('Error:', error)); 
});

    